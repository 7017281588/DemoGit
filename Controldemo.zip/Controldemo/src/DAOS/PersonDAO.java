package DAOS;

import java.util.List;

import org.springframework.stereotype.Repository;

import pojos.Person;


public interface PersonDAO {

	
	public void addPerson(Person p);
	public void updatePerson (Person p);
	public List<Person> listPerson();
	public Person ListPersonbyId(int id);
    public void removePerson(int id);
}
