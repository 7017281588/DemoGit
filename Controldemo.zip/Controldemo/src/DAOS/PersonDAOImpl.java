package DAOS;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import pojos.Person;

@Repository
public class PersonDAOImpl implements PersonDAO {

	private static final Logger logger = 			
			LoggerFactory.getLogger(PersonDAOImpl.class);
	
	SessionFactory sessionFactory ;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addPerson(Person p) {
		
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(p);
		logger.info("Saved :"+p);
		session.close();
		
	}

	@Override
	public void updatePerson(Person p) {
		Session session = this.sessionFactory.getCurrentSession();
		session.update(p);
		logger.info("Updated"+p);
		session.close();
	}

	@Override
	public List<Person> listPerson() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Person> personList = session.createQuery("from Person").list();
		for(Person p :personList)
		{
			logger.info("Person LIst : "+p);
		}
		session.close();
		return personList;
	}

	@Override
	public Person ListPersonbyId(int id) {
		Session session = this.sessionFactory.getCurrentSession();
		Person p = (Person) session.load(Person.class, new Integer(id));
		logger.info("Person loaded successfully, Person details=" + p);
		session.close();
		return p;
	}

	@Override
	public void removePerson(int id) {
		Session session = this.sessionFactory.getCurrentSession();
		Person p = 
		(Person) session.load(Person.class, new Integer(id));
		if (null != p) {
			session.delete(p);
		}else {
			logger.error("Person NOT deleted, with person Id=" +id);
		}
		session.close();
		logger.info("Person deleted successfully, person details=" + p);
		
	}

}
