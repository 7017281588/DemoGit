package Services;

import java.util.List;

import org.springframework.stereotype.Service;

import pojos.Person;


public interface IPersonService {

	public void addPerson(Person p);
	public void updatePerson (Person p);
	public List<Person> listPerson();
	public Person ListPersonbyId(int id);
    public void removePerson(int id);
}
