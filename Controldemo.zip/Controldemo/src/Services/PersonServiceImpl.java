package Services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import DAOS.PersonDAO;
import pojos.Person;

@Service
public class PersonServiceImpl implements IPersonService {

	PersonDAO personDAO;
	
	@Autowired
	public void setPersonDAO(PersonDAO personDAO) {
		this.personDAO = personDAO;
	}

	@Override
	@Transactional
	public void addPerson(Person p) {
		personDAO.addPerson(p);
	}

	@Override
	@Transactional
	public void updatePerson(Person p) {
		personDAO.updatePerson(p);
		
	}

	@Override
	@Transactional
	public List<Person> listPerson() {
		return personDAO.listPerson();
		
	}

	@Override
	@Transactional
	public Person ListPersonbyId(int id) {
		return personDAO.ListPersonbyId(id);
		 
	}

	@Override
	@Transactional
	public void removePerson(int id) {
	personDAO.removePerson(id);
		
	}

}
